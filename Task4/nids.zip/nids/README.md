# Network Intrusion Detection System (Suricata + Python)

Network-based IDS with custom rules, continuous monitoring, automatic response
(temporary IP blocking) and a live dashboard.

```
 Network traffic ─► Suricata (rules/local.rules + ET Open)
                        │ writes alerts
                        ▼
              /var/log/suricata/eve.json ──┬─► src/responder.py ─► nftables (block, TTL) ─► blocks.jsonl
                                           └─► src/dashboard.py (Streamlit) ◄─ blocks.jsonl
```

| Objective | Where |
|---|---|
| 1. Set up Suricata | `scripts/install_suricata.sh` |
| 2. Rules and alerts | `rules/local.rules` (19 rules, SID 9000001+), EVE JSON alerts |
| 3. Continuous monitoring | Suricata service (`systemctl`) + `fast.log` / `eve.json` |
| 4. Response | `src/responder.py` (dry-run by default, whitelist, TTL, action log) |
| 5. Dashboard | `src/dashboard.py` |

## Layout
```
rules/local.rules          custom detection rules
config/whitelist.txt       IPs that must never be blocked
scripts/install_suricata.sh  install + deploy rules + validate
scripts/attack_tests.sh    lab traffic to trigger the rules
src/responder.py           alert -> firewall block
src/dashboard.py           Streamlit dashboard
src/simulate_eve.py        fake alerts, to test without Suricata
justfile                   shortcuts (just install / respond / dashboard / demo)
```

## 1. Quick demo (no Suricata needed)
```bash
pip install -r requirements.txt
python3 src/simulate_eve.py --out eve_demo.json --count 500
python3 src/responder.py --eve eve_demo.json --from-start --exit-at-eof   # dry-run
streamlit run src/dashboard.py -- --eve eve_demo.json --blocks blocks.jsonl
```

## 2. Real deployment (Kali / Debian / Ubuntu, in a lab VM)
```bash
ip -br a                                   # find your interface (eth0, enp0s3...)
sudo ./scripts/install_suricata.sh eth0 "192.168.1.0/24"
sudo suricata -T -c /etc/suricata/suricata.yaml -v     # config + rules OK?
sudo tail -f /var/log/suricata/fast.log
```
VirtualBox: use "Bridged" or "Internal network" with promiscuous mode "Allow All"
on the monitoring VM so it sees the traffic of the others.

## 3. Test the detection (only on machines you own)
From a second VM (attacker, e.g. Kali):
```bash
./scripts/attack_tests.sh <ip_of_victim_or_monitored_host>
```
Each step prints the SID expected in `fast.log`.

## 4. Response
```bash
python3 src/responder.py --eve /var/log/suricata/eve.json                 # dry-run: logs what it WOULD do
sudo python3 src/responder.py --eve /var/log/suricata/eve.json --enforce \
     --whitelist-file config/whitelist.txt --ttl 900 --max-severity 2
```
Policy: block the source IP when alert severity <= 2 (or SIDs given via `--sids`),
for `--ttl` seconds, never for whitelisted IPs. Use `--min-alerts 3 --window 60`
to require several alerts before blocking (fewer false positives).
Check / undo: `sudo nft list set inet nids blocked4`, `sudo nft delete table inet nids`.

> Note: Suricata in IDS mode only observes. Blocking happens on the host running the responder
> (traffic to that host). To block traffic *through* a gateway, run Suricata in IPS mode (NFQUEUE, `action: drop` rules).

## 5. Dashboard
`streamlit run src/dashboard.py -- --eve /var/log/suricata/eve.json --blocks blocks.jsonl`
Shows alerts over time, severity split, top attackers and signatures, attacker x category heatmap,
and the responder actions. (The user running Streamlit must be able to read `eve.json`: `sudo chmod o+r` or add the user to the `suricata` group.)

## Safety
- Test only on your own lab or with written authorisation.
- Always start the responder in dry-run, and keep your admin IP / gateway in `config/whitelist.txt`.
- Tune thresholds in `local.rules` to your traffic before enforcing.

## Possible extensions
- Alerts via email / Telegram / Slack webhook from the responder.
- Send `eve.json` to Elasticsearch + Kibana or Grafana Loki.
- Feed the alerts to your ML models (Random Forest / LSTM) for a hybrid signature + anomaly detection.
