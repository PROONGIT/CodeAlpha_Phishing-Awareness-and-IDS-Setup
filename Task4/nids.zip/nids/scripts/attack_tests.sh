#!/usr/bin/env bash
# Generates harmless test traffic to verify your rules fire.
# ONLY run against machines you own / are authorised to test (e.g. your lab VMs).
# Usage: ./attack_tests.sh <target_ip>
set -u
T="${1:?usage: $0 <target_ip>}"

echo "[1] ICMP sweep (sid 9000001)";  ping -c 15 -i 0.2 "$T" >/dev/null
echo "[2] SYN scan (sid 9000002)";    nmap -sS -p 1-200 -T4 "$T" >/dev/null
echo "[3] Web SQLi (sid 9000020)";    curl -s "http://$T/?id=1%20UNION%20SELECT%201,2" >/dev/null
echo "[4] Web XSS (sid 9000022)";     curl -s "http://$T/?q=<script>alert(1)</script>" >/dev/null
echo "[5] Traversal (sid 9000023)";   curl -s "http://$T/../../etc/passwd" --path-as-is >/dev/null
echo "[6] Scanner UA (sid 9000024)";  curl -s -A "sqlmap/1.7" "http://$T/" >/dev/null
echo "Done. Check: sudo tail /var/log/suricata/fast.log"
