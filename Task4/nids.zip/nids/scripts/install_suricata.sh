#!/usr/bin/env bash
# Installs Suricata on Debian/Ubuntu/Kali, deploys local rules and enables EVE JSON.
# Usage: sudo ./install_suricata.sh <interface> <HOME_NET>
#   e.g. sudo ./install_suricata.sh eth0 "192.168.1.0/24"
set -euo pipefail

IFACE="${1:?usage: $0 <interface> <HOME_NET cidr>}"
HOME_NET="${2:?usage: $0 <interface> <HOME_NET cidr>}"
HERE="$(cd "$(dirname "$0")/.." && pwd)"

apt-get update
apt-get install -y suricata jq nftables

# Official ET Open rule set + our local rules
suricata-update
install -m 644 "$HERE/rules/local.rules" /var/lib/suricata/rules/local.rules

CONF=/etc/suricata/suricata.yaml
cp -n "$CONF" "$CONF.orig"

# Interface + HOME_NET
sed -i "s|^\(\s*HOME_NET:\).*|\1 \"[$HOME_NET]\"|" "$CONF"
sed -i "0,/interface: .*/s//interface: $IFACE/" "$CONF"

# Load local.rules (append to rule-files if missing)
grep -q "local.rules" "$CONF" || sed -i '/^rule-files:/a\  - local.rules' "$CONF"

# Validate config then (re)start
suricata -T -c "$CONF" -v
systemctl enable --now suricata
suricata-update --reload-command "suricatasc -c reload-rules" || systemctl restart suricata

echo "OK. Alerts: /var/log/suricata/eve.json  | fast log: /var/log/suricata/fast.log"
echo "Live view: sudo tail -f /var/log/suricata/eve.json | jq 'select(.event_type==\"alert\")'"
