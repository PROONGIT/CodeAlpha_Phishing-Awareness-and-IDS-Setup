"""
dashboard.py : Streamlit dashboard for Suricata alerts (EVE JSON) + responder actions.

    streamlit run dashboard.py -- --eve /var/log/suricata/eve.json --blocks blocks.jsonl
"""
import argparse
import json
import sys
from pathlib import Path

import pandas as pd
import plotly.express as px
import streamlit as st

p = argparse.ArgumentParser()
p.add_argument("--eve", default="/var/log/suricata/eve.json")
p.add_argument("--blocks", default="blocks.jsonl")
args, _ = p.parse_known_args(sys.argv[1:])

st.set_page_config(page_title="NIDS Dashboard", layout="wide")
st.title("Network Intrusion Detection : Live Dashboard")

eve_path = st.sidebar.text_input("EVE JSON file", args.eve)
blocks_path = st.sidebar.text_input("Responder log", args.blocks)
max_rows = st.sidebar.number_input("Max alerts to load (most recent)", 1000, 500000, 50000, 1000)
refresh = st.sidebar.slider("Auto-refresh (seconds, 0 = off)", 0, 60, 5)
hours = st.sidebar.slider("Time window (hours)", 1, 72, 24)


@st.cache_data(ttl=2)
def load_alerts(path, limit):
    rows = []
    if not Path(path).exists():
        return pd.DataFrame()
    with open(path) as fh:
        for line in fh:
            if '"event_type":"alert"' not in line.replace(" ", ""):
                continue
            try:
                e = json.loads(line)
            except json.JSONDecodeError:
                continue
            a = e.get("alert", {})
            rows.append({
                "time": e.get("timestamp"), "src_ip": e.get("src_ip"),
                "dest_ip": e.get("dest_ip"), "dest_port": e.get("dest_port"),
                "proto": e.get("proto"), "sid": a.get("signature_id"),
                "signature": a.get("signature"), "category": a.get("category"),
                "severity": a.get("severity"),
            })
    df = pd.DataFrame(rows).tail(limit)
    if not df.empty:
        df["time"] = pd.to_datetime(df["time"], utc=True, errors="coerce")
    return df


df = load_alerts(eve_path, int(max_rows))
if df.empty:
    st.info("No alerts found yet. Generate demo data with `python3 src/simulate_eve.py`.")
    st.stop()

cutoff = df["time"].max() - pd.Timedelta(hours=hours)
df = df[df["time"] >= cutoff]
sev_label = {1: "High", 2: "Medium", 3: "Low"}
df["severity_label"] = df["severity"].map(sev_label).fillna("Other")

sev_filter = st.sidebar.multiselect("Severity", ["High", "Medium", "Low"],
                                    default=["High", "Medium", "Low"])
df = df[df["severity_label"].isin(sev_filter)]

blocks = pd.DataFrame()
if Path(blocks_path).exists():
    blocks = pd.read_json(blocks_path, lines=True)

c1, c2, c3, c4 = st.columns(4)
c1.metric("Alerts", f"{len(df):,}")
c2.metric("Unique attackers", df["src_ip"].nunique())
c3.metric("High severity", int((df["severity"] == 1).sum()))
c4.metric("IPs blocked", int((blocks["action"] == "block").sum()) if not blocks.empty else 0)

left, right = st.columns(2)
timeline = df.set_index("time").resample("5min").size().rename("alerts").reset_index()
left.plotly_chart(px.area(timeline, x="time", y="alerts", title="Alerts over time (5 min)"),
                  width="stretch")
right.plotly_chart(px.pie(df, names="severity_label", title="Severity distribution", hole=0.45,
                          color="severity_label",
                          color_discrete_map={"High": "#d62728", "Medium": "#ff7f0e", "Low": "#1f77b4"}),
                   width="stretch")

l2, r2 = st.columns(2)
top_src = df["src_ip"].value_counts().head(10).rename_axis("src_ip").reset_index(name="alerts")
l2.plotly_chart(px.bar(top_src, x="alerts", y="src_ip", orientation="h", title="Top attacker IPs")
                .update_yaxes(autorange="reversed"), width="stretch")
top_sig = df["signature"].value_counts().head(10).rename_axis("signature").reset_index(name="alerts")
r2.plotly_chart(px.bar(top_sig, x="alerts", y="signature", orientation="h", title="Top signatures")
                .update_yaxes(autorange="reversed"), width="stretch")

heat = df.groupby(["src_ip", "category"]).size().reset_index(name="alerts")
st.plotly_chart(px.density_heatmap(heat, x="category", y="src_ip", z="alerts",
                                   title="Attackers vs attack categories"), width="stretch")

st.subheader("Responder actions")
if blocks.empty:
    st.caption("No block/unblock actions logged yet.")
else:
    st.dataframe(blocks.sort_values("ts", ascending=False).head(100), width="stretch")

st.subheader("Latest alerts")
st.dataframe(df.sort_values("time", ascending=False).head(200), width="stretch")

if refresh:
    import time
    time.sleep(refresh)
    st.cache_data.clear()
    st.rerun()
