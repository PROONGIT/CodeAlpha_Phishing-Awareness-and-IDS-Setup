#!/usr/bin/env python3
"""
responder.py : active response for Suricata alerts.

Tails Suricata's eve.json in real time. When an alert matches the policy
(severity threshold or listed signature IDs), the source IP is blocked with
nftables (default) or iptables, for a limited time (TTL), then unblocked.

SAFE BY DEFAULT: runs in --dry-run mode unless you pass --enforce.
Never blocks IPs in the whitelist (your own IP, gateway, DNS, monitoring...).

Usage:
    python3 responder.py --eve /var/log/suricata/eve.json            # dry-run
    sudo python3 responder.py --eve /var/log/suricata/eve.json --enforce
"""
import argparse
import ipaddress
import json
import logging
import os
import subprocess
import sys
import time
from pathlib import Path

DEFAULT_WHITELIST = ["127.0.0.1", "::1"]


def load_whitelist(path, extra):
    nets = []
    entries = list(DEFAULT_WHITELIST) + list(extra or [])
    if path and Path(path).exists():
        for line in Path(path).read_text().splitlines():
            line = line.split("#")[0].strip()
            if line:
                entries.append(line)
    for e in entries:
        try:
            nets.append(ipaddress.ip_network(e, strict=False))
        except ValueError:
            logging.warning("Invalid whitelist entry ignored: %s", e)
    return nets


def is_whitelisted(ip, nets):
    try:
        addr = ipaddress.ip_address(ip)
    except ValueError:
        return True  # unparsable -> never block
    return any(addr in n for n in nets)


class Firewall:
    """Thin wrapper around nftables / iptables."""

    def __init__(self, backend, enforce):
        self.backend = backend
        self.enforce = enforce
        if enforce and backend == "nft":
            self._run(["nft", "add", "table", "inet", "nids"])
            self._run(["nft", "add", "set", "inet", "nids", "blocked4",
                       "{ type ipv4_addr; flags timeout; }"])
            self._run(["nft", "add", "chain", "inet", "nids", "input",
                       "{ type filter hook input priority -10; policy accept; }"])
            self._run(["nft", "add", "rule", "inet", "nids", "input",
                       "ip", "saddr", "@blocked4", "drop"])

    def _run(self, cmd):
        if not self.enforce:
            logging.info("[DRY-RUN] %s", " ".join(cmd))
            return True
        r = subprocess.run(cmd, capture_output=True, text=True)
        if r.returncode != 0 and "exists" not in r.stderr:
            logging.error("Command failed (%s): %s", " ".join(cmd), r.stderr.strip())
            return False
        return True

    def block(self, ip, ttl):
        if self.backend == "nft":
            return self._run(["nft", "add", "element", "inet", "nids", "blocked4",
                              "{ %s timeout %ds }" % (ip, ttl)])
        return self._run(["iptables", "-I", "INPUT", "-s", ip, "-j", "DROP"])

    def unblock(self, ip):
        if self.backend == "nft":
            return True  # nft set element expires by itself (timeout)
        return self._run(["iptables", "-D", "INPUT", "-s", ip, "-j", "DROP"])


def follow(path, from_start=False):
    """Yield new lines appended to a file (handles log rotation)."""
    while not os.path.exists(path):
        time.sleep(1)
    f = open(path, "r")
    inode = os.fstat(f.fileno()).st_ino
    if not from_start:
        f.seek(0, os.SEEK_END)
    while True:
        line = f.readline()
        if line:
            yield line
            continue
        time.sleep(0.5)
        try:
            if os.stat(path).st_ino != inode:  # rotated
                f.close()
                f = open(path, "r")
                inode = os.fstat(f.fileno()).st_ino
        except FileNotFoundError:
            pass
        yield None  # lets the caller run periodic tasks (expiry)


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--eve", default="/var/log/suricata/eve.json")
    ap.add_argument("--enforce", action="store_true",
                    help="really apply firewall rules (default: dry-run)")
    ap.add_argument("--backend", choices=["nft", "iptables"], default="nft")
    ap.add_argument("--max-severity", type=int, default=2,
                    help="block alerts with severity <= N (1=high, 3=low). Default 2")
    ap.add_argument("--sids", type=int, nargs="*", default=[],
                    help="also block these signature IDs regardless of severity")
    ap.add_argument("--ttl", type=int, default=900, help="block duration in seconds")
    ap.add_argument("--min-alerts", type=int, default=1,
                    help="alerts from same IP within --window before blocking")
    ap.add_argument("--window", type=int, default=60)
    ap.add_argument("--whitelist-file", default=None)
    ap.add_argument("--whitelist", nargs="*", default=[])
    ap.add_argument("--action-log", default="blocks.jsonl")
    ap.add_argument("--from-start", action="store_true",
                    help="process the file from the beginning (for tests)")
    ap.add_argument("--exit-at-eof", action="store_true",
                    help="stop when the file is fully read (for tests)")
    args = ap.parse_args()

    logging.basicConfig(level=logging.INFO,
                        format="%(asctime)s %(levelname)s %(message)s")
    nets = load_whitelist(args.whitelist_file, args.whitelist)
    fw = Firewall(args.backend, args.enforce)
    logging.info("Responder started | enforce=%s backend=%s ttl=%ss",
                 args.enforce, args.backend, args.ttl)

    blocked = {}   # ip -> expiry timestamp
    recent = {}    # ip -> list of alert timestamps

    def log_action(action, ip, **kw):
        rec = {"ts": time.strftime("%Y-%m-%dT%H:%M:%S"), "action": action,
               "ip": ip, "enforced": args.enforce, **kw}
        with open(args.action_log, "a") as fh:
            fh.write(json.dumps(rec) + "\n")

    def expire():
        now = time.time()
        for ip in [i for i, t in blocked.items() if t <= now]:
            fw.unblock(ip)
            del blocked[ip]
            logging.info("Unblocked %s (TTL expired)", ip)
            log_action("unblock", ip)

    if args.exit_at_eof:
        def lines():
            with open(args.eve) as fh:
                yield from fh
        source = lines()
    else:
        source = follow(args.eve, args.from_start)

    for line in source:
        expire()
        if not line:
            continue
        try:
            ev = json.loads(line)
        except json.JSONDecodeError:
            continue
        if ev.get("event_type") != "alert":
            continue
        al = ev.get("alert", {})
        ip = ev.get("src_ip", "")
        sev, sid = al.get("severity", 3), al.get("signature_id")
        if not (sev <= args.max_severity or sid in args.sids):
            continue
        if is_whitelisted(ip, nets) or ip in blocked:
            continue
        now = time.time()
        hist = [t for t in recent.get(ip, []) if now - t <= args.window] + [now]
        recent[ip] = hist
        if len(hist) < args.min_alerts:
            continue
        logging.warning("INTRUSION %s | sid=%s sev=%s | %s", ip, sid, sev,
                        al.get("signature"))
        if fw.block(ip, args.ttl):
            blocked[ip] = now + args.ttl
            log_action("block", ip, sid=sid, severity=sev,
                       signature=al.get("signature"), ttl=args.ttl)


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        sys.exit(0)
