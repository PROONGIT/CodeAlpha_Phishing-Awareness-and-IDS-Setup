#!/usr/bin/env python3
"""
simulate_eve.py : writes fake Suricata EVE JSON alerts so you can test the
responder and the dashboard without Suricata or real attacks.

    python3 simulate_eve.py --out eve_demo.json --count 400
    python3 simulate_eve.py --out eve_demo.json --count 0 --live   # keep appending
"""
import argparse
import json
import random
import time
from datetime import datetime, timedelta, timezone

SIGS = [
    (9000002, "LOCAL Recon TCP SYN port scan", 2, "attempted-recon", "TCP", None),
    (9000001, "LOCAL Recon ICMP ping sweep", 3, "network-scan", "ICMP", None),
    (9000010, "LOCAL Brute force SSH connection flood", 1, "attempted-admin", "TCP", 22),
    (9000020, "LOCAL Web SQL injection UNION SELECT", 1, "web-application-attack", "TCP", 80),
    (9000022, "LOCAL Web XSS script tag", 2, "web-application-attack", "TCP", 80),
    (9000023, "LOCAL Web directory traversal", 2, "web-application-attack", "TCP", 443),
    (9000030, "LOCAL DoS SYN flood", 1, "attempted-dos", "TCP", 80),
    (9000040, "LOCAL Suspicious DNS query to .onion/.top/.xyz TLD", 3, "bad-unknown", "UDP", 53),
]
ATTACKERS = ["203.0.113.45", "198.51.100.23", "192.0.2.77", "185.220.101.9", "45.155.205.1"]
VICTIMS = ["192.168.1.10", "192.168.1.20", "192.168.1.30"]


def make_event(ts):
    sid, msg, sev, cat, proto, dport = random.choice(SIGS)
    return {
        "timestamp": ts.strftime("%Y-%m-%dT%H:%M:%S.%f%z"),
        "event_type": "alert",
        "src_ip": random.choice(ATTACKERS),
        "src_port": random.randint(1024, 65535),
        "dest_ip": random.choice(VICTIMS),
        "dest_port": dport or random.choice([22, 80, 443, 3389, 8080]),
        "proto": proto,
        "alert": {"action": "allowed", "gid": 1, "signature_id": sid, "rev": 1,
                  "signature": msg, "category": cat, "severity": sev},
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="eve_demo.json")
    ap.add_argument("--count", type=int, default=400)
    ap.add_argument("--hours", type=float, default=6, help="spread history over N hours")
    ap.add_argument("--live", action="store_true", help="keep appending an alert every ~1s")
    a = ap.parse_args()

    now = datetime.now(timezone.utc)
    with open(a.out, "w") as f:
        for _ in range(a.count):
            ts = now - timedelta(seconds=random.uniform(0, a.hours * 3600))
            f.write(json.dumps(make_event(ts)) + "\n")
    print(f"wrote {a.count} events to {a.out}")
    if a.live:
        with open(a.out, "a", buffering=1) as f:
            while True:
                f.write(json.dumps(make_event(datetime.now(timezone.utc))) + "\n")
                time.sleep(random.uniform(0.5, 2))


if __name__ == "__main__":
    main()
